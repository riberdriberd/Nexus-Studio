# NEXUS AI Creative Studio — Complete Package
### Prepared for Riberd Ng · March 2026

---

## What's Inside

```
NEXUS-Complete-Package/
│
├── README.md                          ← You are here
│
├── 01-NEXUS-Studio/
│   └── nexus-github.html              ← Main app — open in Chrome
│
├── 02-BIM-Notion-Pipeline/
│   ├── SETUP_GUIDE.md                 ← Full setup instructions
│   ├── requirements.txt               ← Python dependencies
│   ├── dynamo/
│   │   ├── BIM_Extract_PoC02.dyn      ← Open in Dynamo 2.x (Revit 2024)
│   │   └── extract_bim_data.py        ← Python extraction script
│   └── agent/
│       ├── agent.py                   ← Main pipeline script
│       ├── sample_bim_export.json     ← Test data (no Revit needed)
│       └── .env.example               ← Copy to .env and fill in keys
│
├── 03-BIM-Presentation/
│   └── bim-presentation.html          ← 9-slide interactive presentation
│
└── 04-Onboarding/
    └── nexus-onboarding-guide.html    ← Team setup guide
```

---

## Quick Start

### NEXUS Studio (01)
1. Open `nexus-github.html` in Google Chrome
2. Click ⚙️ → enter your API keys → Save & Connect
3. All 4 status dots turn green = fully live

**API Keys needed:**
- Claude: console.anthropic.com
- Gemini: aistudio.google.com/app/apikey
- GitHub: github.com/settings/tokens
- Google OAuth: console.cloud.google.com

### BIM-to-Notion Pipeline (02)
```bash
pip install anthropic notion-client python-dotenv
cd 02-BIM-Notion-Pipeline/agent
cp .env.example .env        # fill in your keys
python agent.py --input sample_bim_export.json --dry-run
```

### BIM Presentation (03)
Open `bim-presentation.html` in Chrome.
Use arrow keys to navigate slides. Avatar presenter included.

### Team Onboarding (04)
Upload `nexus-onboarding-guide.html` to your shared Google Drive folder.
Send team invitation emails (see conversation with Claude for templates).

---

## Team Email List
- wynn_lei_phyu@yahoo.com
- riberdriberd@gmail.com
- jianxunbak@yahoo.com.sg
- helenhuang002@gmail.com
- linuslohyf@gmail.com

---

## Built with NEXUS AI Creative Studio
Claude API (Anthropic) · Google Gemini · GitHub Integration · Google Drive
