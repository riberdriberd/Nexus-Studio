"""
PoC-02 | BIM-to-Notion Dynamic Pipeline
Stage 2 & 3: agent.py — Analyze with Claude API + Serve to Notion

Requirements:
    pip install anthropic notion-client python-dotenv

Usage:
    python agent.py --input bim_export.json
    python agent.py --input bim_export.json --dry-run   (skip Notion push)
"""

import argparse
import json
import os
import sys
from datetime import datetime
from dotenv import load_dotenv
import anthropic
from notion_client import Client as NotionClient

load_dotenv()

# ─────────────────────────────────────────────────────────────
# CONFIG  (set via .env or environment variables)
# ─────────────────────────────────────────────────────────────
ANTHROPIC_API_KEY  = os.getenv("ANTHROPIC_API_KEY", "")
NOTION_API_KEY     = os.getenv("NOTION_API_KEY", "")
NOTION_DATABASE_ID = os.getenv("NOTION_DATABASE_ID", "")   # Rooms DB
NOTION_PAGE_ID     = os.getenv("NOTION_PAGE_ID", "")       # Dashboard parent page

# ─────────────────────────────────────────────────────────────
# STAGE 2A: PARSE & VALIDATE JSON
# ─────────────────────────────────────────────────────────────
def load_bim_data(filepath: str) -> dict:
    print(f"[1/5] Loading BIM data from: {filepath}")
    with open(filepath, "r", encoding="utf-8") as f:
        data = json.load(f)
    meta = data.get("metadata", {})
    summary = data.get("summary", {})
    print(f"      Project : {meta.get('project_name', 'Unknown')}")
    print(f"      Exported: {meta.get('exported_at', 'Unknown')}")
    print(f"      Rooms   : {summary.get('total_rooms', 0)}")
    print(f"      Doors   : {summary.get('total_doors', 0)}")
    print(f"      Windows : {summary.get('total_windows', 0)}")
    print(f"      Struct  : {summary.get('total_structural_elements', 0)}")
    return data


# ─────────────────────────────────────────────────────────────
# STAGE 2B: ANALYTICAL LOGIC (Python)
# ─────────────────────────────────────────────────────────────
def run_analytics(data: dict) -> dict:
    print("[2/5] Running analytical logic...")
    rooms     = data.get("rooms", [])
    finishes  = data.get("finishes", [])
    doors     = data.get("doors", [])
    windows   = data.get("windows", [])
    structural = data.get("structural", [])

    # Room analytics
    areas      = [r["area_m2"] for r in rooms if "area_m2" in r]
    by_level   = {}
    for r in rooms:
        lvl = r.get("level", "Unknown")
        by_level.setdefault(lvl, {"count": 0, "total_area": 0})
        by_level[lvl]["count"]      += 1
        by_level[lvl]["total_area"] += r.get("area_m2", 0)

    # Finish completeness
    finish_complete = sum(
        1 for f in finishes
        if f.get("floor_finish") and f.get("wall_finish") and f.get("ceiling_finish")
    )

    # Door/window ratios per room
    door_count   = len(doors)
    window_count = len(windows)
    room_count   = len(rooms)

    # Fire-rated doors
    fire_doors = [d for d in doors if d.get("fire_rating")]

    # Structural by category
    struct_by_cat = {}
    for s in structural:
        cat = s.get("category", "Other")
        struct_by_cat[cat] = struct_by_cat.get(cat, 0) + 1

    return {
        "room_count"          : room_count,
        "total_area_m2"       : round(sum(areas), 2),
        "avg_room_area_m2"    : round(sum(areas) / len(areas), 2) if areas else 0,
        "largest_room_m2"     : max(areas) if areas else 0,
        "smallest_room_m2"    : min(areas) if areas else 0,
        "rooms_by_level"      : by_level,
        "finish_complete_pct" : round(finish_complete / room_count * 100, 1) if room_count else 0,
        "door_count"          : door_count,
        "window_count"        : window_count,
        "fire_rated_doors"    : len(fire_doors),
        "doors_per_room"      : round(door_count / room_count, 2) if room_count else 0,
        "structural_by_cat"   : struct_by_cat,
    }


# ─────────────────────────────────────────────────────────────
# STAGE 2C: CLAUDE API — NATURAL LANGUAGE SUMMARY
# ─────────────────────────────────────────────────────────────
def generate_ai_summary(data: dict, analytics: dict) -> dict:
    print("[3/5] Generating AI summaries via Claude API...")

    client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)

    # Build a condensed prompt (not full raw JSON to stay within token limits)
    prompt = f"""
You are a BIM data analyst. Based on the following extracted Revit model data, 
produce a structured report for non-technical stakeholders in a Notion dashboard.

=== PROJECT METADATA ===
{json.dumps(data.get('metadata', {}), indent=2)}

=== ANALYTICAL SUMMARY ===
{json.dumps(analytics, indent=2)}

=== SAMPLE ROOMS (first 10) ===
{json.dumps(data.get('rooms', [])[:10], indent=2)}

=== SAMPLE FINISHES (first 10) ===
{json.dumps(data.get('finishes', [])[:10], indent=2)}

=== SAMPLE DOORS (first 5) ===
{json.dumps(data.get('doors', [])[:5], indent=2)}

=== SAMPLE STRUCTURAL (first 5) ===
{json.dumps(data.get('structural', [])[:5], indent=2)}

Please respond ONLY with a JSON object (no markdown, no backticks) with these keys:
{{
  "executive_summary": "2-3 sentence overview for a project manager",
  "room_insights": "Key observations about room distribution, sizes, and levels",
  "finish_status": "Assessment of finish data completeness and any gaps",
  "openings_notes": "Observations about doors/windows, fire ratings, unusual items",
  "structural_notes": "Brief note on structural elements found",
  "data_quality_flags": ["list", "of", "potential", "data", "issues"],
  "recommended_actions": ["list", "of", "3-5", "recommended", "next", "steps"],
  "status_tag": "one of: Complete | Needs Review | Incomplete"
}}
"""

    response = client.messages.create(
        model="claude-opus-4-5",
        max_tokens=1500,
        messages=[{"role": "user", "content": prompt}]
    )

    raw = response.content[0].text.strip()
    # Strip any accidental markdown fences
    raw = raw.replace("```json", "").replace("```", "").strip()

    try:
        summary = json.loads(raw)
    except json.JSONDecodeError:
        summary = {"executive_summary": raw, "status_tag": "Needs Review"}

    print(f"      Status tag: {summary.get('status_tag', 'Unknown')}")
    return summary


# ─────────────────────────────────────────────────────────────
# STAGE 3: PUSH TO NOTION
# ─────────────────────────────────────────────────────────────
def push_to_notion(data: dict, analytics: dict, ai_summary: dict, dry_run: bool = False):
    print("[4/5] Pushing to Notion dashboard...")
    if dry_run:
        print("      [DRY RUN] Skipping Notion API calls.")
        return

    notion = NotionClient(auth=NOTION_API_KEY)
    meta   = data.get("metadata", {})
    now    = datetime.utcnow().isoformat() + "Z"

    # ── 3a. Update / Create Dashboard Summary Page ──────────
    if NOTION_PAGE_ID:
        children = [
            _heading("📊 BIM Dashboard — " + meta.get("project_name", "Project"), 1),
            _callout(ai_summary.get("executive_summary", ""), "💼"),
            _heading("Project Stats", 2),
            _table_from_dict({
                "Total Rooms"            : str(analytics["room_count"]),
                "Total Floor Area"       : f"{analytics['total_area_m2']} m²",
                "Avg Room Size"          : f"{analytics['avg_room_area_m2']} m²",
                "Finish Completeness"    : f"{analytics['finish_complete_pct']}%",
                "Doors"                  : str(analytics["door_count"]),
                "Windows"                : str(analytics["window_count"]),
                "Fire-Rated Doors"       : str(analytics["fire_rated_doors"]),
                "Last Sync"              : meta.get("exported_at", now),
            }),
            _heading("🤖 AI Analysis", 2),
            _callout(ai_summary.get("room_insights", ""), "🏠"),
            _callout(ai_summary.get("finish_status", ""), "🎨"),
            _callout(ai_summary.get("openings_notes", ""), "🚪"),
            _callout(ai_summary.get("structural_notes", ""), "🏗️"),
            _heading("⚠️ Data Quality Flags", 2),
            _bulleted_list(ai_summary.get("data_quality_flags", [])),
            _heading("✅ Recommended Actions", 2),
            _bulleted_list(ai_summary.get("recommended_actions", [])),
        ]

        notion.pages.update(
            page_id=NOTION_PAGE_ID,
            properties={"title": {"title": [{"text": {"content": f"BIM Dashboard — {meta.get('project_name', 'Project')}"}}]}}
        )
        # Clear and repopulate
        existing_blocks = notion.blocks.children.list(block_id=NOTION_PAGE_ID)
        for block in existing_blocks["results"]:
            notion.blocks.delete(block_id=block["id"])
        notion.blocks.children.append(block_id=NOTION_PAGE_ID, children=children)
        print("      ✓ Dashboard page updated")

    # ── 3b. Push Rooms to Database ───────────────────────────
    if NOTION_DATABASE_ID:
        rooms = data.get("rooms", [])
        finishes_map = {f["room_id"]: f for f in data.get("finishes", [])}
        pushed = 0
        for room in rooms[:50]:  # limit to 50 for demo; paginate for full sets
            finish = finishes_map.get(room["id"], {})
            properties = {
                "Room Name"   : {"title"  : [{"text": {"content": room.get("name", "Unnamed")}}]},
                "Number"      : {"rich_text": [{"text": {"content": str(room.get("number", ""))}}]},
                "Level"       : {"rich_text": [{"text": {"content": str(room.get("level", ""))}}]},
                "Area (m²)"   : {"number" : room.get("area_m2", 0)},
                "Department"  : {"rich_text": [{"text": {"content": str(room.get("department", ""))}}]},
                "Floor Finish": {"rich_text": [{"text": {"content": str(finish.get("floor_finish", ""))}}]},
                "Wall Finish" : {"rich_text": [{"text": {"content": str(finish.get("wall_finish", ""))}}]},
                "Ceil. Finish": {"rich_text": [{"text": {"content": str(finish.get("ceiling_finish", ""))}}]},
                "Status"      : {"select" : {"name": ai_summary.get("status_tag", "Needs Review")}},
            }
            try:
                notion.pages.create(parent={"database_id": NOTION_DATABASE_ID}, properties=properties)
                pushed += 1
            except Exception as e:
                print(f"      ⚠ Room {room.get('name')}: {e}")
        print(f"      ✓ Pushed {pushed} rooms to Notion database")


# ─────────────────────────────────────────────────────────────
# NOTION BLOCK HELPERS
# ─────────────────────────────────────────────────────────────
def _heading(text: str, level: int = 1) -> dict:
    t = f"heading_{level}"
    return {
        "object": "block", "type": t,
        t: {"rich_text": [{"type": "text", "text": {"content": text}}]}
    }

def _callout(text: str, emoji: str = "ℹ️") -> dict:
    return {
        "object": "block", "type": "callout",
        "callout": {
            "rich_text": [{"type": "text", "text": {"content": text}}],
            "icon": {"emoji": emoji}
        }
    }

def _bulleted_list(items: list) -> list:
    blocks = []
    for item in items:
        blocks.append({
            "object": "block", "type": "bulleted_list_item",
            "bulleted_list_item": {"rich_text": [{"type": "text", "text": {"content": str(item)}}]}
        })
    return blocks

def _table_from_dict(d: dict) -> dict:
    rows = []
    for k, v in d.items():
        rows.append({
            "type": "table_row",
            "table_row": {"cells": [[{"type": "text", "text": {"content": k}}],
                                     [{"type": "text", "text": {"content": str(v)}}]]}
        })
    return {
        "object": "block", "type": "table",
        "table": {"table_width": 2, "has_column_header": False, "children": rows}
    }


# ─────────────────────────────────────────────────────────────
# SAVE PROCESSED OUTPUT
# ─────────────────────────────────────────────────────────────
def save_output(data: dict, analytics: dict, ai_summary: dict):
    print("[5/5] Saving processed output...")
    output = {
        "metadata"   : data.get("metadata", {}),
        "analytics"  : analytics,
        "ai_summary" : ai_summary,
        "processed_at": datetime.utcnow().isoformat() + "Z",
    }
    out_path = "bim_processed.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2)
    print(f"      ✓ Saved to {out_path}")


# ─────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="PoC-02 BIM-to-Notion Agent")
    parser.add_argument("--input",   required=True, help="Path to bim_export.json from Dynamo")
    parser.add_argument("--dry-run", action="store_true", help="Skip Notion push (testing mode)")
    args = parser.parse_args()

    if not ANTHROPIC_API_KEY:
        print("ERROR: ANTHROPIC_API_KEY not set in environment or .env file")
        sys.exit(1)

    if not args.dry_run and (not NOTION_API_KEY or not NOTION_DATABASE_ID):
        print("WARNING: NOTION_API_KEY or NOTION_DATABASE_ID not set — running in dry-run mode")
        args.dry_run = True

    print("\n╔══════════════════════════════════════════════╗")
    print("║   PoC-02 | BIM-to-Notion Pipeline Agent     ║")
    print("╚══════════════════════════════════════════════╝\n")

    data       = load_bim_data(args.input)
    analytics  = run_analytics(data)
    ai_summary = generate_ai_summary(data, analytics)
    push_to_notion(data, analytics, ai_summary, dry_run=args.dry_run)
    save_output(data, analytics, ai_summary)

    print("\n✅ Pipeline complete!\n")
    if args.dry_run:
        print("   Run without --dry-run to push live to Notion.\n")


if __name__ == "__main__":
    main()
