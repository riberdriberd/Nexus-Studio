# PoC-02 | BIM-to-Notion Dynamic Pipeline
## Setup & Usage Guide

---

## Architecture Overview

```
Revit 2024
    └── Dynamo 2.x  ──► bim_export.json
                              │
                    agent.py (Python)
                    ├── Analytics logic
                    └── Claude API (AI summaries)
                              │
                         Notion API
                    ├── Dashboard Page (AI summaries + stats)
                    └── Rooms Database (structured room data)
```

---

## Step 1: Set Up the Dynamo Script

### Install
1. Open **Revit 2024** with your project
2. Launch **Dynamo** (Manage tab → Dynamo)
3. Open `dynamo/BIM_Extract_PoC02.dyn`
4. Click **Run** (top-left, set to **Manual** mode)

### Output
- Creates `~/Desktop/bim_export.json`
- Contains: Rooms, Finishes, Doors, Windows, Structural elements

### Notes for Revit 2024
- Ensure your model has rooms placed (not just room bounding walls)
- Rooms must have **area > 0** to be included (unplaced rooms are skipped)
- Finish parameters (`Floor Finish`, `Wall Finish`, `Ceiling Finish`) are standard Revit room parameters — populate them in your model for best results

---

## Step 2: Set Up Python Environment

```bash
# Create virtual environment (recommended)
python -m venv venv
source venv/bin/activate        # Mac/Linux
venv\Scripts\activate           # Windows

# Install dependencies
pip install anthropic notion-client python-dotenv
```

---

## Step 3: Configure API Keys

```bash
# Copy the template
cp agent/.env.example agent/.env

# Edit .env with your keys
```

### Getting your Anthropic API key
- Go to https://console.anthropic.com/
- Create an API key
- Paste into `.env` as `ANTHROPIC_API_KEY`

### Getting your Notion API key
1. Go to https://www.notion.so/my-integrations
2. Click **+ New integration**
3. Name it `BIM Pipeline`, select your workspace
4. Copy the **Internal Integration Token** → paste as `NOTION_API_KEY`

### Setting up the Notion Workspace

#### Create the Dashboard Page
1. In Notion, create a new **Page** (e.g., "BIM Dashboard")
2. Share it with your integration: click **...** → **Connections** → select your integration
3. Copy the page ID from the URL:
   `notion.so/myworkspace/`**`abc123def456...`**`?pvs=4`
4. Paste into `.env` as `NOTION_PAGE_ID`

#### Create the Rooms Database
1. Inside the Dashboard Page, create a new **Database (inline)**
2. Add these properties:

| Property Name | Type    |
|---------------|---------|
| Room Name     | Title   |
| Number        | Text    |
| Level         | Text    |
| Area (m²)     | Number  |
| Department    | Text    |
| Floor Finish  | Text    |
| Wall Finish   | Text    |
| Ceil. Finish  | Text    |
| Status        | Select  |

3. Add Select options for Status: `Complete`, `Needs Review`, `Incomplete`
4. Copy the database ID from the URL and paste as `NOTION_DATABASE_ID`

---

## Step 4: Run the Pipeline

```bash
cd agent

# Test first (dry run — no Notion changes)
python agent.py --input sample_bim_export.json --dry-run

# Run with your real export
python agent.py --input ~/Desktop/bim_export.json --dry-run

# Full run (pushes to Notion)
python agent.py --input ~/Desktop/bim_export.json
```

### Expected Output
```
╔══════════════════════════════════════════════╗
║   PoC-02 | BIM-to-Notion Pipeline Agent     ║
╚══════════════════════════════════════════════╝

[1/5] Loading BIM data from: bim_export.json
      Project : Sample Office Building
      Rooms   : 6
      Doors   : 8
      Windows : 10
      Struct  : 12
[2/5] Running analytical logic...
[3/5] Generating AI summaries via Claude API...
      Status tag: Needs Review
[4/5] Pushing to Notion dashboard...
      ✓ Dashboard page updated
      ✓ Pushed 6 rooms to Notion database
[5/5] Saving processed output...
      ✓ Saved to bim_processed.json

✅ Pipeline complete!
```

---

## Automation (Optional)

### Windows Task Scheduler
Run every day at 9am:
```
Action: Start a program
Program: python
Arguments: C:\path\to\agent\agent.py --input C:\Users\you\Desktop\bim_export.json
```

### Mac/Linux Cron
```bash
# Run daily at 9am
0 9 * * * cd /path/to/agent && python agent.py --input ~/Desktop/bim_export.json
```

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| `ANTHROPIC_API_KEY not set` | Check your `.env` file is in the `agent/` folder |
| `Rooms: 0` in Dynamo output | Ensure rooms are placed in Revit (not just room separation lines) |
| Notion push fails | Confirm your integration is connected to the page/database |
| `json.JSONDecodeError` | Claude returned unexpected format — rerun, it's rare |
| Dynamo Python error | Make sure you're using Dynamo 2.x with CPython3 engine |

---

## Project Structure

```
bim-notion-pipeline/
├── dynamo/
│   └── BIM_Extract_PoC02.dyn       ← Open in Dynamo 2.x
├── agent/
│   ├── agent.py                    ← Main pipeline script
│   ├── sample_bim_export.json      ← Test data (no Revit needed)
│   └── .env.example                ← Copy to .env and fill in keys
└── SETUP_GUIDE.md                  ← This file
```
