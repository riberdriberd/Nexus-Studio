# Dynamo Python Script (Run inside Dynamo 2.x / Revit 2024)
# Node: Python Script
# Place this code in a Dynamo Python Script node
# Output: JSON file path

import clr
import json
import os
import sys
from datetime import datetime

clr.AddReference('RevitAPI')
clr.AddReference('RevitAPIUI')
clr.AddReference('RevitServices')

from Autodesk.Revit.DB import *
from RevitServices.Persistence import DocumentManager
from RevitServices.Transactions import TransactionManager

# ─── CONFIG ───────────────────────────────────────────────────────────────────
OUTPUT_DIR = r"C:\BIM-Notion-Pipeline\output"
OUTPUT_FILE = os.path.join(OUTPUT_DIR, "bim_data.json")

# ─── SETUP ────────────────────────────────────────────────────────────────────
doc = DocumentManager.Instance.CurrentDBDocument
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ─── HELPERS ──────────────────────────────────────────────────────────────────
def safe_param(element, param_name):
    """Safely retrieve a parameter value from a Revit element."""
    try:
        param = element.LookupParameter(param_name)
        if param:
            if param.StorageType == StorageType.Double:
                return round(param.AsDouble() * 0.0929, 2)  # sqft to sqm
            elif param.StorageType == StorageType.String:
                return param.AsString() or ""
            elif param.StorageType == StorageType.Integer:
                return param.AsInteger()
            elif param.StorageType == StorageType.ElementId:
                el = doc.GetElement(param.AsElementId())
                return el.Name if el else ""
    except:
        return None
    return None

def get_level_name(element):
    try:
        level_id = element.LevelId
        level = doc.GetElement(level_id)
        return level.Name if level else "Unknown"
    except:
        return "Unknown"

# ─── EXTRACT ROOMS ────────────────────────────────────────────────────────────
def extract_rooms():
    rooms = []
    collector = FilteredElementCollector(doc).OfCategory(
        BuiltInCategory.OST_Rooms).WhereElementIsNotElementType()
    
    for room in collector:
        try:
            area_param = room.LookupParameter("Area")
            area = round(area_param.AsDouble() * 0.0929, 2) if area_param else 0.0
            
            rooms.append({
                "id": room.Id.IntegerValue,
                "name": room.LookupParameter("Name").AsString() if room.LookupParameter("Name") else "Unnamed",
                "number": room.LookupParameter("Number").AsString() if room.LookupParameter("Number") else "",
                "level": get_level_name(room),
                "area_sqm": area,
                "department": safe_param(room, "Department") or "",
                "occupancy": safe_param(room, "Occupancy") or "",
                "comments": safe_param(room, "Comments") or ""
            })
        except Exception as e:
            pass
    return rooms

# ─── EXTRACT FINISHES ─────────────────────────────────────────────────────────
def extract_finishes():
    finishes = []
    collector = FilteredElementCollector(doc).OfCategory(
        BuiltInCategory.OST_Rooms).WhereElementIsNotElementType()
    
    for room in collector:
        try:
            finishes.append({
                "room_id": room.Id.IntegerValue,
                "room_name": room.LookupParameter("Name").AsString() if room.LookupParameter("Name") else "Unnamed",
                "floor_finish": safe_param(room, "Floor Finish") or "",
                "wall_finish": safe_param(room, "Wall Finish") or "",
                "ceiling_finish": safe_param(room, "Ceiling Finish") or "",
                "base_finish": safe_param(room, "Base Finish") or ""
            })
        except:
            pass
    return finishes

# ─── EXTRACT DOORS ────────────────────────────────────────────────────────────
def extract_doors():
    doors = []
    collector = FilteredElementCollector(doc).OfCategory(
        BuiltInCategory.OST_Doors).WhereElementIsNotElementType()
    
    for door in collector:
        try:
            door_type = doc.GetElement(door.GetTypeId())
            doors.append({
                "id": door.Id.IntegerValue,
                "level": get_level_name(door),
                "mark": safe_param(door, "Mark") or "",
                "type_name": door_type.Name if door_type else "Unknown",
                "width_mm": round((safe_param(door, "Width") or 0) * 304.8, 0),
                "height_mm": round((safe_param(door, "Height") or 0) * 304.8, 0),
                "fire_rating": safe_param(door, "Fire Rating") or "",
                "comments": safe_param(door, "Comments") or ""
            })
        except:
            pass
    return doors

# ─── EXTRACT WINDOWS ──────────────────────────────────────────────────────────
def extract_windows():
    windows = []
    collector = FilteredElementCollector(doc).OfCategory(
        BuiltInCategory.OST_Windows).WhereElementIsNotElementType()
    
    for win in collector:
        try:
            win_type = doc.GetElement(win.GetTypeId())
            windows.append({
                "id": win.Id.IntegerValue,
                "level": get_level_name(win),
                "mark": safe_param(win, "Mark") or "",
                "type_name": win_type.Name if win_type else "Unknown",
                "width_mm": round((safe_param(win, "Width") or 0) * 304.8, 0),
                "height_mm": round((safe_param(win, "Height") or 0) * 304.8, 0),
                "sill_height_mm": round((safe_param(win, "Sill Height") or 0) * 304.8, 0),
                "comments": safe_param(win, "Comments") or ""
            })
        except:
            pass
    return windows

# ─── EXTRACT STRUCTURAL ───────────────────────────────────────────────────────
def extract_structural():
    structural = {"columns": [], "beams": [], "walls": []}
    
    # Structural Columns
    cols = FilteredElementCollector(doc).OfCategory(
        BuiltInCategory.OST_StructuralColumns).WhereElementIsNotElementType()
    for col in cols:
        try:
            col_type = doc.GetElement(col.GetTypeId())
            structural["columns"].append({
                "id": col.Id.IntegerValue,
                "level": get_level_name(col),
                "mark": safe_param(col, "Mark") or "",
                "type_name": col_type.Name if col_type else "Unknown",
                "material": safe_param(col, "Structural Material") or ""
            })
        except:
            pass
    
    # Structural Framing (Beams)
    beams = FilteredElementCollector(doc).OfCategory(
        BuiltInCategory.OST_StructuralFraming).WhereElementIsNotElementType()
    for beam in beams:
        try:
            beam_type = doc.GetElement(beam.GetTypeId())
            structural["beams"].append({
                "id": beam.Id.IntegerValue,
                "level": get_level_name(beam),
                "mark": safe_param(beam, "Mark") or "",
                "type_name": beam_type.Name if beam_type else "Unknown",
                "material": safe_param(beam, "Structural Material") or ""
            })
        except:
            pass
    
    # Structural Walls
    walls = FilteredElementCollector(doc).OfCategory(
        BuiltInCategory.OST_Walls).WhereElementIsNotElementType()
    for wall in walls:
        try:
            wall_type = doc.GetElement(wall.GetTypeId())
            if wall_type and "structural" in wall_type.Name.lower():
                structural["walls"].append({
                    "id": wall.Id.IntegerValue,
                    "level": get_level_name(wall),
                    "mark": safe_param(wall, "Mark") or "",
                    "type_name": wall_type.Name if wall_type else "Unknown",
                    "length_m": round((safe_param(wall, "Length") or 0) * 0.3048, 2),
                    "area_sqm": round((safe_param(wall, "Area") or 0) * 0.0929, 2)
                })
        except:
            pass
    
    return structural

# ─── ASSEMBLE & EXPORT ────────────────────────────────────────────────────────
bim_data = {
    "metadata": {
        "project_name": doc.Title,
        "extracted_at": datetime.now().isoformat(),
        "revit_version": "Revit 2024",
        "extractor": "BIM-Notion Pipeline v1.0"
    },
    "rooms": extract_rooms(),
    "finishes": extract_finishes(),
    "doors": extract_doors(),
    "windows": extract_windows(),
    "structural": extract_structural()
}

with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
    json.dump(bim_data, f, indent=2, ensure_ascii=False)

# Dynamo output
OUT = OUTPUT_FILE
